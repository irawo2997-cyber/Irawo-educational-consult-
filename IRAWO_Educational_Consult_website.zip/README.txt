IRAWO Educational Consult - Free Starter Website

Files:
- index.html: complete mobile-friendly homepage.

How to use:
1. Open index.html in a web browser to preview the site.
2. The WhatsApp buttons already use 09011440883.
3. The question/CBT sections are placeholders for the next build stage.

Next development stage:
- Add JAMB/SSCE subject pages
- Add question database
- Add CBT scoring
- Add student accounts
- Add premium materials and payment
